luku1 = int(input("anna luku: "))
luku2 = int(input("anna toinen luku: "))

if luku1 > luku2:
    print("luku", luku1, "on suurempi")
    
else:
    print("luku", luku2, "on suurempi")