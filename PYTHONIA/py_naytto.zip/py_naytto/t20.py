def keskiarvo(a, b, c, d):
    ka = (a + b + c + d) / 4  
    print("Keskiarvo on:", ka)

keskiarvo(1, 2, 3, 4)
