print("mitävalitset: ")
print("1 - menen koodaamaan")
print("2 - menen kotiin")
print("3 - menen kouluun")
print("4 - menen kahville")
print("5 - menen pois")

num = int(input("anna numero 1-5: "))

if num == 1:
    print("Tervetuloa !")
elif num == 2:
    print("Hyvää kotimatkaa")
elif num == 3:
    print("Opiskele ahkerasti!")
elif num == 4:
    print("Ota kahvin kanssa myös kakkua :")
elif num == 5:
    print("Kiitos käynnistä!")