sana = input("anna sana: ")

if "k" in sana:
    print ("K on merkkijonossa ")
    
else:
    print ("K ei ole merkkijonossa ")