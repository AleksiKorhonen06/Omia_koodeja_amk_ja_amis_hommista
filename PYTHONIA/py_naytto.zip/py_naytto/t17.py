lista = ["Rikonen","Ruotsalainen","Huhtamäki","Männistö","Tapani","Mäkinen"]

lista.sort()
for nimi in lista:
    print(nimi)
