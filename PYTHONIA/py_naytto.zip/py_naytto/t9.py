sana = input("anna sana: ")
index = 0
while index < len(sana):
    print (sana[:: 1] [index] ) 
    index += 1