import random
num = random.randint(15, 70)
print(num)
