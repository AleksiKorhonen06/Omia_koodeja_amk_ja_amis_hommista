
pisteet = int(input("How many points [0-100]:"))

if pisteet >= 0 and pisteet <= 40:
    print("0")

if pisteet >= 41 and pisteet <= 50:
    print("1")

if pisteet >= 51 and pisteet <= 60:
    print("2")

if pisteet >= 61 and pisteet <= 70:
    print("3")

if pisteet >= 71 and pisteet <= 80:
    print("4")
    
if pisteet >= 81 and pisteet <= 90:
    print("5")

