ika = int(input("kerro ikäsi: "))

if ika >= 18:
    print ("olet täysi-ikäinen")
else:
    print ("olet alaikäinen")