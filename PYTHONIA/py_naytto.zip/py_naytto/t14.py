sana = input("anna sana: ") 

uusi = sana.replace("a", "b")

print("uusi sanasi on", uusi)