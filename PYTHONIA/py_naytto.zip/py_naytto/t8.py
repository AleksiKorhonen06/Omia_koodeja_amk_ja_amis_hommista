sala = input("Password:")

while True:
    sala_yritys = input("Password:")
    if sala == sala_yritys:
        break
    print("Väärin!")

print("Oikein!")