sana = input("anna sana: ")
print(sana[::2]) 