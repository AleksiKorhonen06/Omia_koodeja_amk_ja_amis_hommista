loppu = int(input("anna num mihin asti tulostetaan"))

for num in range(loppu):
   print(num,end="," )