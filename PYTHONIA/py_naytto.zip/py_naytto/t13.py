sana = input("anna sana: ")

montako = sana.count("k") 

print("sanassa oli", montako, "k kirjainta")