etu = input("anna etunimesi: ")
suku = input("anna sukunimesi: ")

print("terve", etu, suku)